/*package com.bespin.auto;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "member";
	}
//	@RequestMapping(value="/member2", method = RequestMethod.GET)
//	public String search() {
//		logger.info("searchController");
//
//		return "member2";
//	}
//	
}*/

package com.bespin.auto;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bespin.auto.domain.User;
import com.bespin.auto.service.UserService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	@Autowired private UserService userService;

	@RequestMapping(value = "search", method = RequestMethod.POST)
	public String getDB(Model model, @RequestParam("action") String id,  @RequestParam("selectAttr") String attr ) throws IOException {
		int i = 1;
		if(attr.equals("num")) i=0;
		else if(attr.equals("name")) i=1;
		else i=2;

		List<User> vo = userService.getDB(id, i);
		model.addAttribute("listAll", vo);
		
		return "member2";
	}
	
	@RequestMapping(value = "searchAll", method = RequestMethod.GET)
	public String getDBAll(Model model) throws Exception {
		List<User> vo = userService.getDBAll();
		model.addAttribute("listAll", vo);
		
		return "member2";
	}
	
	@RequestMapping(value = "searchUpdate", method = {RequestMethod.GET, RequestMethod.POST})
	public String getDBUpdate(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Model model) throws IOException {
		String num = httpServletRequest.getParameter("num");
		logger.info("searchUpdate({})", num);
		List<User> vo = userService.getDB(num, 0);
		User use = new User();
		model.addAttribute("listAll", vo);
	
		use.setNum(vo.get(0).getNum());
		use.setName(vo.get(0).getName());
		use.setTeam(vo.get(0).getTeam());
		use.setAge(vo.get(0).getAge());

		return "UserView_ASC";
	}
	
	
	/*---------------삽입----------------------------------*/
	@RequestMapping(value="/member", method=RequestMethod.GET)
	public void insertGET(User user,Model model) throws Exception{
		
	}
	@RequestMapping(value="/member",method=RequestMethod.POST)
	public String insertPOST(User user, Model model) throws Exception{
		userService.insert(user);
		user.getNum();
		model.addAttribute("result","성공");
		
		return "succes";
	}

	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedDate = dateFormat.format(date);
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping(value = "/list", method = {RequestMethod.GET, RequestMethod.POST})
	public String list1(Locale locale, Model model) {
		return "member2";

	}
	
	@RequestMapping(value = "/modify", method = {RequestMethod.GET, RequestMethod.POST})
	public String modify(Locale locale, Model model) {
		return "UserView_ASC";
	}
	
	
	/*-------------------------------delete------------------------------------*/
	
	@RequestMapping(value = "/delete/{Arr}", method = {RequestMethod.DELETE,RequestMethod.POST})
	@ResponseBody
	public void deleteCustomer(@PathVariable final String[] Arr) {
		String [] bn = Arr;

		logger.info("delete({})", Arr);

			User user = new User();
			for(int i =0;i<bn.length;i++) {
				user.setCurnum(Integer.parseInt(bn[i].replace("BG", "")));
				int result = userService.delete(user.getCurnum());
			}
			
	}
	
	@RequestMapping(value= "/delete_m/{del}", method = {RequestMethod.DELETE,RequestMethod.POST})
	@ResponseBody
	public String deleteDELETE(@PathVariable (value="del")String num, Model model) throws Exception {
		userService.delete_m(Integer.parseInt(num));
		System.out.println("dd");
		logger.info("delete({})", Integer.parseInt(num));
		return "redirect:/searchAll";
	}
}
