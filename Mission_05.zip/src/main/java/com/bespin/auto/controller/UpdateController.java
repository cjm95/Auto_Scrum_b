package com.bespin.auto.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bespin.auto.domain.User;
import com.bespin.auto.service.UserService;

@Controller
public class UpdateController {

	private static final Logger logger = LoggerFactory.getLogger(UpdateController.class);
	@Autowired private UserService userService;

	/**
	 * Simply selects the home view to render by returning its name.
	 */

	@RequestMapping(value="/UserView_ASC", method = RequestMethod.GET)
	public String update(Model model, @RequestParam("num") String bid) throws Exception{
		logger.info("UpdateController"+bid);
		User context = new User();
		context.setNum(Integer.parseInt(bid.replaceAll(" ", "")));
		model.addAttribute("num", context);
		return "UserView_ASC";
	}
	
	@RequestMapping(value = "/update/{num}", method = {RequestMethod.PUT, RequestMethod.POST})
	public String update( @PathVariable final int num, 
			@RequestParam(value = "usernum") String usernum,
            @RequestParam(value = "username") String username,
            @RequestParam(value = "department") String department,
            @RequestParam(value = "age") int age) {
		
		
		  User user = new User();
		  user.setAge(age);
		  user.setName(username);
		  user.setNum(Integer.parseInt(usernum)); 
		  user.setTeam(department);
		  user.setCurnum(num);
		 
		logger.info("update({})", user);

		// BoardService의 메소드를 사용해서 게시글을 수정(DB 테이블 수정)
		int result = userService.update(user.getCurnum(), user);
		
		// 게시글 수정 이후에 상세보기 페이지로 이동(redirect)
		return "redirect:/searchAll";
	}
	
	

}
