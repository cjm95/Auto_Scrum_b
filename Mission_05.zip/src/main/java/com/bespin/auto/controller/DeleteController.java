package com.bespin.auto.controller;


public class DeleteController {
	

}
